package com.example.hrms.biz.request.controller.Rest;

import com.example.hrms.biz.request.model.Request;
import com.example.hrms.biz.request.model.criteria.RequestCriteria;
import com.example.hrms.biz.request.model.dto.RequestDto;
import com.example.hrms.biz.request.service.RequestService;
import com.example.hrms.biz.user.model.User;
import com.example.hrms.biz.user.service.UserService;
import com.example.hrms.common.http.criteria.Page;
import com.example.hrms.common.http.model.Result;
import com.example.hrms.common.http.model.ResultData;
import com.example.hrms.common.http.model.ResultPageData;
import com.example.hrms.exception.ResourceNotFoundException;
import com.example.hrms.security.SecurityUtils;
import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@Tag(name = "API requests")
@RestController
@RequestMapping("/api/v1/requests")
public class RequestRestController {
    private final RequestService requestService;
    private final UserService userService;

    public RequestRestController(RequestService requestService, UserService userService) {
        this.requestService = requestService;
        this.userService = userService;
    }

    @Operation(summary = "List requests")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Get success",
                    content = {@Content(mediaType = "application/json",
                            array = @ArraySchema(schema = @Schema(implementation = RequestDto.Resp.class)))
                    }),
            @ApiResponse(responseCode = "400", description = "Invalid request",
                    content = @Content)})
    @GetMapping("")
    public ResultPageData<List<RequestDto.Resp>> list(Page page, RequestCriteria criteria) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        // Nếu là ADMIN → trả về toàn bộ danh sách
        if (authentication.getAuthorities().stream()
                .anyMatch(auth -> auth.getAuthority().equals("ADMIN"))) {
            int total = requestService.count(criteria);
            ResultPageData<List<RequestDto.Resp>> response = new ResultPageData<>(criteria, total);
            response.setResultData(requestService.list(page, criteria));
            return response;
        }
        // Nếu không phải ADMIN → chỉ trả về request của user hiện tại
        else {
            String username = SecurityUtils.getCurrentUsername();
            criteria.setUsername(username); // Lọc theo username
            int total = requestService.count(criteria);
            ResultPageData<List<RequestDto.Resp>> response = new ResultPageData<>(criteria, total);
            response.setResultData(requestService.list(page, criteria));
            return response;
        }
    }
    @Operation(summary = "Get requests of staff in the same department")
    @PreAuthorize("hasAuthority('SUPERVISOR')")
    @GetMapping("/staff-requests")
    public ResultPageData<List<RequestDto.Resp>> getRequestsForSupervisor(Page page) {
        String supervisorUsername = SecurityUtils.getCurrentUsername();
        User supervisor = userService.getUserByUsername(supervisorUsername);

        if (supervisor == null || !supervisor.isSupervisor()) {
            throw new RuntimeException("User is not a supervisor");
        }

        int total = requestService.countRequestsByDepartment(supervisor.getDepartmentId());
        ResultPageData<List<RequestDto.Resp>> response = new ResultPageData<>(new RequestCriteria(), total);
        response.setResultData(total > 0 ? requestService.getRequestsForSupervisor(page, supervisor.getDepartmentId()) : Collections.emptyList());

        return response;
    }

    @Operation(summary = "Approve or Reject Request")
    @PreAuthorize("hasAuthority('SUPERVISOR')")
    @PutMapping("/{requestId}/approve-reject")
    public Result approveOrRejectRequest(@PathVariable Long requestId, @RequestParam String action) {
        String supervisorUsername = SecurityContextHolder.getContext().getAuthentication().getName();
        try {
            requestService.approveOrRejectRequest(requestId, action, supervisorUsername);
            return new Result("Success", "Request " + action.toLowerCase() + "d successfully");
        } catch (IllegalArgumentException e) {
            return new Result("Error", "Invalid action: " + action);
        } catch (RuntimeException e) {
            return new Result("Error", e.getMessage());
        }
    }

    @Operation(summary = "Get total leave days of a user")
    @GetMapping("/days-off")
    public ResultData<Long> getTotalLeaveDays(@RequestParam String username) {
        long totalLeaveDays = requestService.getTotalLeaveDays(username);
        return new ResultData<>(Result.SUCCESS, "Total leave days retrieved successfully", totalLeaveDays);
    }

    @Operation(summary = "Create a new request")
    @PostMapping("/create")
    public Result createRequest(@RequestBody RequestDto.Req requestDto, @RequestParam String username) {
        boolean success = requestService.createRequest(username, requestDto);
        return success ? new Result("Success", "Request created successfully.") : new Result("Failed", "Failed to create request");
    }

    @Operation(summary = "Update a request")
    @PreAuthorize("hasAuthority('SUPERVISOR')")
    @PutMapping("/{id}")
    public Result updateRequest(@PathVariable Long id, @RequestBody Request request) {
        String supervisorUsername = SecurityContextHolder.getContext().getAuthentication().getName();
        request.setRequestId(id);
        try {
            boolean updated = requestService.updateRequest(request);
            return updated ? new Result("Success", "Request updated successfully by " + supervisorUsername)
                    : new Result("Error", "Request not found.");
        } catch (IllegalArgumentException e) {
            return new Result("Error", "Invalid request: " + e.getMessage());
        }
    }

    @Operation(summary = "Delete a request")
    @PreAuthorize("hasAuthority('SUPERVISOR')")
    @DeleteMapping("/{id}")
    public Result deleteRequest(@PathVariable Long id) {
        try {
            requestService.deleteRequest(id);
            return new Result("Success", "Request deleted successfully");
        } catch (ResourceNotFoundException e) {
            return new Result("Error", "Request not found");
        }
    }
}
